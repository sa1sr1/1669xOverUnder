#pragma once
void slapper_toggle();
