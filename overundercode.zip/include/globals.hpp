#pragma once
#include "main.h"

extern pros::Motor intake;
extern ez::Piston wingLeft;
extern ez::Piston wingRight;
extern ez::Piston ratchet;
extern pros::Motor slapper;
extern pros::Motor hang;
